module.exports = {
  MAX_UINT16: 2n ** 16n - 1n,
  MAX_UINT32: 2n ** 32n - 1n,
  MAX_UINT48: 2n ** 48n - 1n,
  MAX_UINT64: 2n ** 64n - 1n,
  MAX_UINT128: 2n ** 128n - 1n,
};
