const iterate = require('../test/helpers/iterate');
const strings = require('../test/helpers/strings');

module.exports = {
  ...iterate,
  ...strings,
};
