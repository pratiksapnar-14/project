---
'openzeppelin-solidity': minor
---

`Bytes`: Add an `equal` function to compare byte buffers.
