---
'openzeppelin-solidity': minor
---

`Memory`: Add library with utilities to manipulate memory
