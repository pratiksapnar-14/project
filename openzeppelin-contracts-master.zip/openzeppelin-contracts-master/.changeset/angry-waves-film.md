---
'openzeppelin-solidity': minor
---

`WebAuthn`: Add a library for verifying WebAuthn Authentication Assertions.
