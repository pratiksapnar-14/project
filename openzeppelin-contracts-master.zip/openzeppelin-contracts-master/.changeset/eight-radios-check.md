---
'openzeppelin-solidity': minor
---

`Checkpoints`: Add a new checkpoint variant `Checkpoint256` using `uint256` type for the value and key.
