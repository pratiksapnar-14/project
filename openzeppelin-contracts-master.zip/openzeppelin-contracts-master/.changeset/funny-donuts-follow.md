---
'openzeppelin-solidity': minor
---

`IERC7751`: Add the interface for custom error wrapping of bubbled up reverts.
