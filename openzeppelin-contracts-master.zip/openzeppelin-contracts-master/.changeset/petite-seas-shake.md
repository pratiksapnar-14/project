---
'openzeppelin-solidity': minor
---

`SignerWebAuthn`: Add an abstract signer that verifies WebAuthn signatures, with a P256 fallback.
