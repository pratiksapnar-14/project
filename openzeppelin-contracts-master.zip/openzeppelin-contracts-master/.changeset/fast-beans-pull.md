---
'openzeppelin-solidity': minor
---

`Bytes`: Add a `clz` function to count the leading zero bits in a `bytes` buffer.
