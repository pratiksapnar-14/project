---
'openzeppelin-solidity': minor
---

`Math`: Add a `clz` function to count the leading zero bits in a `uint256` value.
