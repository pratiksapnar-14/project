---
'openzeppelin-solidity': minor
---

`IERC7786`: Add the (draft) interface for ERC-7786 "Cross-Chain Messaging Gateway"
