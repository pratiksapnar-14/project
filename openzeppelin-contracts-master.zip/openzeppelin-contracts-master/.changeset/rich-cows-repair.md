---
'openzeppelin-solidity': minor
---

`InteroperableAddress`: Add a library for formatting and parsing ERC-7930 interoperable addresses.
