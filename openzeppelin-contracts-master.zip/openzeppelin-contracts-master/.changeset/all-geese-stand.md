---
'openzeppelin-solidity': patch
---

Add constructors to the different signers.
