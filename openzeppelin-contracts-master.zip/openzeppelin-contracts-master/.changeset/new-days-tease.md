---
'openzeppelin-solidity': minor
---

`Strings`: Add `toHexString(bytes)`.
